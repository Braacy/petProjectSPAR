//
//  Product.swift
//  TestUnitSpar2.0
//
//  Created by Владислав  on 09.08.2024.
//

import Foundation

struct Product {
    var id: String
    var rating: String
    var title: String
    var imageUrl: String
    var price: Int
    var country: String?
    
//    var orderCount: Int
//    var isRecomend: Bool
}
