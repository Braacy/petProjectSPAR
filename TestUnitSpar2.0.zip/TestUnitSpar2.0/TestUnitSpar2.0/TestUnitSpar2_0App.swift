//
//  TestUnitSpar2_0App.swift
//  TestUnitSpar2.0
//
//  Created by Владислав  on 09.08.2024.
//

import SwiftUI

let screen = UIScreen.main.bounds

@main
struct TestUnitSpar2_0App: App {
    var body: some Scene {
        WindowGroup {
            AuthView()
        }
    }
}
