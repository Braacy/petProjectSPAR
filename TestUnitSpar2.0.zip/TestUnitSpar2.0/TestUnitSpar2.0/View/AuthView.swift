//
//  ContentView.swift
//  TestUnitSpar2.0
//
//  Created by Владислав  on 09.08.2024.
//

import SwiftUI

struct AuthView: View {
    
    @State private var isAuth = true
    
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    
    @State private var isTabBarView = false
    
    var body: some View {
        VStack(spacing: 20)  {
            
            Text(isAuth ? "Авторизация" : "Регистрация")
                .padding(isAuth ? 16 : 24)
                .padding(.horizontal, 30)
                .font(.title2.bold())
                .background(Color("whiteAlpha"))
                .cornerRadius(isAuth ? 40 : 60)
            
            VStack {
                TextField("Введите Email", text: $email)
                    .padding()
                    .background(Color("whiteAlpha"))
                    .cornerRadius(13)
                    .padding(8)
                    .padding(.horizontal, 12)
                
                SecureField("Введите пароль", text: $password)
                    .padding()
                    .background(Color("whiteAlpha"))
                    .cornerRadius(13)
                    .padding(8)
                    .padding(.horizontal, 12)
                
                if !isAuth {
                    SecureField("Повторите пароль", text: $confirmPassword)
                        .padding()
                        .background(Color("whiteAlpha"))
                        .cornerRadius(13)
                        .padding(8)
                        .padding(.horizontal, 12)
                }
                
                Button {
                    
                    if isAuth {
                        print("autorize")
                        
                        isTabBarView.toggle()
                    } else {
                        print("registrate")
                        self.email = ""
                        self.password = ""
                        self.confirmPassword = ""
                        self.isAuth.toggle()
                    }
                    
                } label: {
                    Text(isAuth ? "Войти" : "Создать аккаунт")
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(LinearGradient(colors: [Color("red"), Color("green")], startPoint: .leading, endPoint: .trailing))
                        .cornerRadius(13)
                        .padding(8)
                        .padding(.horizontal, 12)
                        .font(.title3.bold())
                        .foregroundColor(.black)
                    
                    }
                Button {
                    isAuth.toggle()
                } label: {
                    Text(isAuth ? "Регистрация" : "Есть аккаунт")
                        .padding(.horizontal)
                        .frame(maxWidth: .infinity)
                        
                        .cornerRadius(13)
                        .padding(8)
                        .padding(.horizontal, 12)
                        .font(.title3.bold())
                        .foregroundColor(.black)
                    
                    }
                }
            .padding()
            .background(Color("whiteAlpha"))
            .cornerRadius(15)
            .padding(isAuth ? 30 : 12)
            
            }
            .frame(maxWidth: .infinity,  maxHeight: .infinity)
            .background(Image("bg") .ignoresSafeArea()
                .blur(radius: isAuth ? 0 : 7))
            .animation(Animation.easeInOut(duration: 0.3), value: isAuth)
        
            .fullScreenCover(isPresented: $isTabBarView) {
                TabBar()
            }
        }
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            AuthView()
        }
    }


