//
//  CartView.swift
//  TestUnitSpar2.0
//
//  Created by Владислав  on 09.08.2024.
//

import SwiftUI

struct CartView: View {
    var body: some View {
        Text("Корзина!!")
    }
}

struct CartView_Previews: PreviewProvider {
    static var previews: some View {
        CartView()
    }
}
