//
//  ProductCell.swift
//  TestUnitSpar2.0
//
//  Created by Владислав  on 09.08.2024.
//

import SwiftUI

struct ProductCell: View {
    
    var product: Product
    
    var body: some View {
        VStack(spacing: 10) {
            Image("1")
                .resizable()
//                .aspectRatio(contentMode: .fill)
//                .clipped()
//                .cornerRadius(15)
            VStack{
                Text(product.rating)
                    .padding(.trailing, 100)
                    .font(.custom("AvenirNext-regular", size: 12))
                Text(product.title)
                    .padding(.trailing)
                    .font(.custom("AvenirNext-regular", size: 12))
                Text("\(product.price) ₽/кг")
                    .padding(.trailing, 90)
                    
                    .font(.custom("AvenirNext-bold", size: 12))
            }.padding(.vertical, 10)
            
        }.frame(width: screen.width * 0.45, height: screen.width * 0.65)
            .background(.white)
            .cornerRadius(15)
            .shadow(radius: 5)
            
            
        
        
    }
    
}

struct ProductCell_Previews: PreviewProvider {
    static var previews: some View {
        ProductCell(product: Product(id: "1", rating: "⭐️ 4.1",
                                     title: " сыр Ламбер 500/0 230г", imageUrl: "Not found",
                                     price: 99 ))
    }
}
