//
//  ProductDetailView.swift
//  TestUnitSpar2.0
//
//  Created by Владислав  on 09.08.2024.
//

import SwiftUI

struct ProductDetailView: View {
    
    var viewModel: ProductDetailViewModel
    
    
    var body: some View {
        Text("\(viewModel.product.title)!")
    }
}

struct ProductDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ProductDetailView(viewModel: ProductDetailViewModel(product: Product(
            id: "1",
            rating: "⭐️ 4.1",
            title: " сыр Ламбер 500/0 230г",
            imageUrl: "Not found",
            price: 99 )))
    }
}
