//
//  ProfileView.swift
//  TestUnitSpar2.0
//
//  Created by Владислав  on 09.08.2024.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("Профиль!!")
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}

