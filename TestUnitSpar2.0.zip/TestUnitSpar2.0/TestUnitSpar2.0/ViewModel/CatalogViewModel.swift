//
//  CatalogViewModel.swift
//  TestUnitSpar2.0
//
//  Created by Владислав  on 09.08.2024.
//

import Foundation

class CatalogViewModel: ObservableObject {
    
    static let shared = CatalogViewModel()
    
    
    var popularProducts = [Product(id: "1", rating: "⭐️ 4.1",
                            title: " сыр Ламбер 500/0 230г",
                            imageUrl: "Not found",
                            price: 99 ),
                           Product(id: "2", rating: "⭐️ 4.1",
                            title: "Энергетический напиток",
                            imageUrl: "Not found",
                            price: 99699 ),
                           Product(id: "3", rating: "⭐️ 4.1",
                            title: " Салат Овощной с Крабовыми Палочками",
                            imageUrl: "Not found",
                            price: 250 ),
                           Product(id: "4", rating: "⭐️ 4.1",
                            title: " Дорадо Охлажденная Непотрошенная 300-400 г",
                            imageUrl: "Not found",
                            price: 5 ),
                           Product(id: "5", rating: "⭐️ 4.1",
                            title: "Ролл маленькая Япония 216г",
                            imageUrl: "Not found",
                            price: 367)
    ]
    
    var products = [Product(id: "1", rating: "⭐️ 4.1",
                            title: " сыр Ламбер 500/0 230г",
                            imageUrl: "Not found",
                            price: 99 ),
                    Product(id: "2", rating: "⭐️ 4.1",
                            title: "Энергетический напиток",
                            imageUrl: "Not found",
                            price: 99699 ),
                    Product(id: "3", rating: "⭐️ 4.1",
                            title: " Салат Овощной с Крабовыми Палочками",
                            imageUrl: "Not found",
                            price: 250 ),
                    Product(id: "4", rating: "⭐️ 4.1",
                            title: " Дорадо Охлажденная Непотрошенная 300-400 г",
                            imageUrl: "Not found",
                            price: 5 ),
                    Product(id: "5", rating: "⭐️ 4.1",
                            title: "Ролл маленькая Япония 216г",
                            imageUrl: "Not found",
                            price: 367)
    ]
    
}
