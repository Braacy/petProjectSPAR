//
//  ProductDetailViewModel.swift
//  TestUnitSpar2.0
//
//  Created by Владислав  on 09.08.2024.
//

import Foundation


class ProductDetailViewModel: ObservableObject {
    
   @Published var product: Product
    
    init(product: Product) {
        self.product = product
    }
}
